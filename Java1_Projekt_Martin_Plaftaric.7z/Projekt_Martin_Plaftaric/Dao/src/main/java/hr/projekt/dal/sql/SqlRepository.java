
package hr.projekt.dal.sql;

import hr.projekt.dal.Repository;
import hr.projekt.model.FavoriteArticles;
import hr.projekt.model.HackerNewsArticle;
import hr.projekt.model.User;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

/**
 *
 * @author martin.plaftaric
 */

public class SqlRepository implements Repository {

    private static final String ID_ARTICLE = "IDArticle";
    private static final String TITLE = "Title";
    private static final String LINK = "Link";
    private static final String DESCRIPTION = "Description";
    private static final String PICTURE_PATH = "PicturePath";
    private static final String PUBLISHED_DATE = "PublishedDate";

    private static final String CREATE_ARTICLE = "{ CALL createArticle (?,?,?,?,?,?) }";
    private static final String UPDATE_ARTICLE = "{ CALL updateArticle (?,?,?,?,?,?) }";
    private static final String DELETE_ARTICLE = "{ CALL deleteArticle (?) }";
    private static final String DELETE_ARTICLES = "{ CALL deleteArticles }";
    private static final String SELECT_ARTICLE = "{ CALL selectArticle (?) }";
    private static final String SELECT_ARTICLES = "{ CALL selectArticles }";
    
    private static final String ID_USER = "IDAccount";
    private static final String USERNAME = "Username";
    private static final String PASSHASH = "Passhash";
    private static final String ISADMIN = "IsAdmin";

    private static final String CREATE_USER = "{ CALL createAccount (?,?,?,?) }";
    private static final String UPDATE_USER = "{ CALL updateAccount (?,?,?,?) }";
    private static final String DELETE_USER = "{ CALL deleteAccount (?) }";
    private static final String SELECT_USER = "{ CALL selectAccount (?) }";
    
    private static final String ID_ACCOUNT_ARTICLE = "IDAccount_Article";
    private static final String ACCOUNT_ID = "AccountID";
    private static final String ARTICLE_ID = "ArticleID";
    
    private static final String CREATE_ACCOUNT_ARTICLE = "{ CALL createAccount_Article (?,?,?) }";
    private static final String UPDATE_ACCOUNT_ARTICLE = "{ CALL updateAccount_Article (?,?,?) }";
    private static final String DELETE_ACCOUNT_ARTICLE = "{ CALL deleteAccount_Article (?,?) }";
    private static final String DELETE_ACCOUNT_ARTICLES = "{ CALL deleteAccount_Articles }";
    private static final String SELECT_ACCOUNT_ARTICLES = "{ CALL selectAccount_Articles (?) }";
    
    
    @Override
    public int createArticle(HackerNewsArticle article) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(CREATE_ARTICLE)) {

            stmt.setString(TITLE, article.getTitle());
            stmt.setString(LINK, article.getLink());
            stmt.setString(DESCRIPTION, article.getDescription());
            stmt.setString(PICTURE_PATH, article.getPicturePath());
            stmt.setString(PUBLISHED_DATE, article.getPublishedDate().format(HackerNewsArticle.DATE_FORMATTER));
            stmt.registerOutParameter(ID_ARTICLE, Types.INTEGER);

            stmt.executeUpdate();
            return stmt.getInt(ID_ARTICLE);
        }
    }

    @Override
    public void createArticles(List<HackerNewsArticle> articles) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(CREATE_ARTICLE)) {

            for (HackerNewsArticle article : articles) {
                stmt.setString(TITLE, article.getTitle());
                stmt.setString(LINK, article.getLink());
                stmt.setString(DESCRIPTION, article.getDescription());
                stmt.setString(PICTURE_PATH, article.getPicturePath());
                stmt.setString(PUBLISHED_DATE, article.getPublishedDate().format(HackerNewsArticle.DATE_FORMATTER));
                stmt.registerOutParameter(ID_ARTICLE, Types.INTEGER);

                stmt.executeUpdate();
            }
        }
    }

    @Override
    public void updateArticle(int id, HackerNewsArticle data) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(UPDATE_ARTICLE)) {

            stmt.setString(TITLE, data.getTitle());
            stmt.setString(LINK, data.getLink());
            stmt.setString(DESCRIPTION, data.getDescription());
            stmt.setString(PICTURE_PATH, data.getPicturePath());
            stmt.setString(PUBLISHED_DATE, data.getPublishedDate().format(HackerNewsArticle.DATE_FORMATTER));
            stmt.setInt(ID_ARTICLE, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteArticle(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(DELETE_ARTICLE)) {

            stmt.setInt(ID_ARTICLE, id);

            stmt.executeUpdate();
        }
    }
    
        @Override
    public void deleteArticles() throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(DELETE_ARTICLES)) {
            stmt.executeUpdate();
        }
    }

    @Override
    public Optional<HackerNewsArticle> selectArticle(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(SELECT_ARTICLE)) {

            stmt.setInt(ID_ARTICLE, id);
            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {
                    return Optional.of(new HackerNewsArticle(
                            rs.getInt(ID_ARTICLE),
                            rs.getString(TITLE),
                            rs.getString(LINK),
                            rs.getString(DESCRIPTION),
                            rs.getString(PICTURE_PATH),
                            LocalDateTime.parse(rs.getString(PUBLISHED_DATE), HackerNewsArticle.DATE_FORMATTER)));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public List<HackerNewsArticle> selectArticles() throws Exception {
        List<HackerNewsArticle> articles = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(SELECT_ARTICLES); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                articles.add(new HackerNewsArticle(
                        rs.getInt(ID_ARTICLE),
                        rs.getString(TITLE),
                        rs.getString(LINK),
                        rs.getString(DESCRIPTION),
                        rs.getString(PICTURE_PATH),
                        LocalDateTime.parse(rs.getString(PUBLISHED_DATE), HackerNewsArticle.DATE_FORMATTER)));
            }
        }
        return articles;
    }
    
    @Override
    public int createUser(User user) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(CREATE_USER)) {
            
            stmt.setString(USERNAME, user.getUsername());
            stmt.setInt(PASSHASH, user.getPassHash());
            stmt.setBoolean(ISADMIN, user.isIsAdmin());
            stmt.registerOutParameter(ID_USER, Types.INTEGER);

            stmt.executeUpdate();
            return stmt.getInt(ID_USER);
            
        }
    }

    @Override
    public void updateUser(int id, User user) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(UPDATE_USER)) {

            stmt.setString(USERNAME, user.getUsername());
            stmt.setInt(PASSHASH, user.getPassHash());
            stmt.setBoolean(ISADMIN, user.isIsAdmin());
            stmt.setInt(ID_USER, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteUser(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(DELETE_USER)) {

            stmt.setInt(ID_USER, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public Optional<User> selectUser(String username) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(SELECT_USER)) {

            stmt.setString(USERNAME, username);
            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {
                    return Optional.of(new User(
                            rs.getInt(ID_USER),
                            rs.getString(USERNAME),
                            rs.getString(PASSHASH),
                            rs.getBoolean(ISADMIN)
                    ));
                }
            }
        }
        return Optional.empty();
    }
    
    @Override
    // nije bas na pravom mjestu, al ajde progledat cemo mi kroz prste
    public boolean validateUser(User user) throws Exception {
        User validateUser = selectUser(user.getUsername()).get();
        return (validateUser.getUsername().equals(user.getUsername()) && validateUser.getPassHash() == user.getPassHash());
    }

    @Override
    public int createFavorite(int accountID, int articleID) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(CREATE_ACCOUNT_ARTICLE)) {

            stmt.setInt(ACCOUNT_ID, accountID);
            stmt.setInt(ARTICLE_ID, articleID);
            stmt.registerOutParameter(ID_ACCOUNT_ARTICLE, Types.INTEGER);

            stmt.executeUpdate();
            return stmt.getInt(ID_ACCOUNT_ARTICLE);
        }
    }

    @Override
    public void updateFavorite(int id, int userID, int articleID) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(UPDATE_ACCOUNT_ARTICLE)) {

            stmt.setInt(ACCOUNT_ID, userID);
            stmt.setInt(ARTICLE_ID, articleID);
            stmt.setInt(ID_ACCOUNT_ARTICLE, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteFavorite(int userID, int articleID) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(DELETE_ACCOUNT_ARTICLE)) {

            stmt.setInt(ACCOUNT_ID, userID);
            stmt.setInt(ARTICLE_ID, articleID);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteFavorites() throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(DELETE_ACCOUNT_ARTICLES)) {
            stmt.executeUpdate();
        }
    }

    @Override
    public List<HackerNewsArticle> selectFavorites(int accountID) throws Exception {
        List<HackerNewsArticle> articles = new ArrayList<>();
        List<FavoriteArticles> favoritearticles = new ArrayList<>(); 
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection(); CallableStatement stmt = con.prepareCall(SELECT_ACCOUNT_ARTICLES)) {

            stmt.setInt(ACCOUNT_ID, accountID);
            
            try (ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                favoritearticles.add(new FavoriteArticles(
                        rs.getInt(ID_ACCOUNT_ARTICLE),
                        rs.getInt(ACCOUNT_ID),
                        rs.getInt(ARTICLE_ID)));
                }
            }
        }
        // dohvati favorite artikle korisnika pa ih dohvati iz baze
        favoritearticles.forEach
        (x->{
            try {
                articles.add(selectArticle(x.getArticleID()).get());
            } catch (Exception ex) {
                Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        return articles;
    }
}
