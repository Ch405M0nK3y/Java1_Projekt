/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hr.projekt.dal;

import hr.projekt.model.HackerNewsArticle;
import hr.projekt.model.User;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author martin.plaftaric
 */
public interface Repository {

    int createArticle(HackerNewsArticle article) throws Exception;

    void createArticles(List<HackerNewsArticle> articles) throws Exception;

    void updateArticle(int id, HackerNewsArticle data) throws Exception;

    void deleteArticle(int id) throws Exception;
    
    void deleteArticles() throws Exception;

    Optional<HackerNewsArticle> selectArticle(int id) throws Exception;

    List<HackerNewsArticle> selectArticles() throws Exception;
    
    int createUser(User user) throws Exception;

    void updateUser(int id, User user) throws Exception;

    void deleteUser(int id) throws Exception;
    
    Optional<User> selectUser(String username) throws Exception;
    
    boolean validateUser(User user) throws Exception;
    
    int createFavorite (int userID, int articleID)throws Exception;
    
    void updateFavorite (int id, int accountID, int articleID)throws Exception;
    
    void deleteFavorite (int userID, int articleID)throws Exception;
    
    void deleteFavorites ()throws Exception;

    List<HackerNewsArticle> selectFavorites(int accountID) throws Exception;

}
