/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hr.projekt.model;

/**
 *
 * @author martin.plaftaric
 */
public class User {
    
    private int id;
    private String username;
    private int passHash;
    private boolean isAdmin;

    public User() {
    }
    
    public User(String username, String passHash) {
        this.username = username;
        this.passHash = passHash.hashCode();
    }
    
    public User(int id, String username, String passHash, boolean isAdmin) {
        this.id = id;
        this.username = username;
        this.passHash = Integer.parseInt(passHash);
        this.isAdmin = isAdmin;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPassHash() {
        return passHash;
    }

    public void setPassHash(String passHash) {
        this.passHash = passHash.hashCode();
    }

    public boolean isIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    @Override
    public String toString() {
        return "username=" + username;
    }
    
    
    
}
