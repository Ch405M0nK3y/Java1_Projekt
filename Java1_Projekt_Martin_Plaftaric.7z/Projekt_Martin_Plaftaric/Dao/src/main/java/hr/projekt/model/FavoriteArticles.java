/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hr.projekt.model;

/**
 *
 * @author martin.plaftaric
 */
public class FavoriteArticles {
    
    private int id;
    private int accountID;
    private int articleID;

    public FavoriteArticles() {
    }
    
    public FavoriteArticles(int id, int accountID, int articleID) {
        this.id = id;
        this.accountID = accountID;
        this.articleID = articleID;
    }

    public int getId() {
        return id;
    }

    public int getAccountID() {
        return accountID;
    }

    public int getArticleID() {
        return articleID;
    }
 
}
